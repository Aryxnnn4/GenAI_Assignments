# Exercise 1 – Age Calculator (by Aryan)
# This program asks for a birthdate, validates input, and calculates age.

import datetime

def valid_date(date_str):
    try:
        month, day, year = map(int, date_str.split('/'))
        return datetime.date(year, month, day)
    except Exception:
        return None

def main():
    birth_input = input("Enter your birthdate (mm/dd/yyyy): ")
    birth_date = valid_date(birth_input)

    if not birth_date:
        print("Invalid date format! Please enter in mm/dd/yyyy.")
        return

    today = datetime.date.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

    print("Your age:", age)
    euro_format = f"{birth_date.day:02d}/{birth_date.month:02d}/{birth_date.year}"
    print("Birthdate (European format):", euro_format)

if __name__ == "__main__":
    main()
