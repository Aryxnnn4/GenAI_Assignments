# Exercise 4 – Weather Data Fetcher & Analyzer (by Aryan)
# Fetches weather using API and logs info to a file.

import requests

def fetch_weather(city, api_key):
    try:
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
        res = requests.get(url)
        data = res.json()
        if "main" not in data:
            print("Invalid city or API error!")
            return None
        return data
    except Exception:
        print("Network error.")
        return None

def analyze_weather(data):
    temp = data["main"]["temp"]
    wind = data["wind"]["speed"]
    hum = data["main"]["humidity"]

    if temp <= 10:
        summary = "Cold"
    elif temp <= 24:
        summary = "Mild"
    else:
        summary = "Hot"

    alerts = []
    if wind > 10: alerts.append("High wind alert!")
    if hum > 80: alerts.append("Humid conditions!")
    return summary + " | " + ", ".join(alerts)

def log_weather(city, filename, api_key):
    w = fetch_weather(city, api_key)
    if not w:
        return
    summary = analyze_weather(w)
    with open(filename, "a") as f:
        f.write(f"{city},{w['main']['temp']},{summary}
")

