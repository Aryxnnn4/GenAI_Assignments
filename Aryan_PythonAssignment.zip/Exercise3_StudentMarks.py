# Exercise 3 – Student Marks Processor (by Aryan)
# Reads student data, computes grades, and writes structured results.

import numpy as np

def compute_grade(score):
    if score >= 90: return "A"
    if score >= 75: return "B"
    if score >= 60: return "C"
    if score >= 50: return "D"
    return "F"

def main():
    input_file = "students.txt"
    output_file = "results.csv"

    records = []
    try:
        with open(input_file, "r") as f:
            for line in f:
                reg, exam, coursework = line.strip().split(",")
                exam = float(exam)
                coursework = float(coursework)
                overall = exam*0.6 + coursework*0.4
                grade = compute_grade(overall)
                records.append((reg, exam, coursework, overall, grade))
    except Exception as e:
        print("Error reading file:", e)
        return

    dtype = [("reg", "U20"), ("exam", float), ("cw", float), ("overall", float), ("grade", "U2")]
    arr = np.array(records, dtype=dtype)
    arr_sorted = np.sort(arr, order="overall")[::-1]

    with open(output_file, "w") as f:
        f.write("Reg,Exam,CW,Overall,Grade
")
        for r in arr_sorted:
            f.write(f"{r['reg']},{r['exam']},{r['cw']},{r['overall']:.2f},{r['grade']}
")

    print("Grades Count:")
    unique, counts = np.unique(arr_sorted["grade"], return_counts=True)
    for u, c in zip(unique, counts):
        print(u, ":", c)

if __name__ == "__main__":
    main()
