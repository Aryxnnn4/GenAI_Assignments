# Exercise 2 – Prime Number Generator (by Aryan)
# Generates primes between two limits after validating input.

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

def main():
    try:
        start = int(input("Enter range start: "))
        end = int(input("Enter range end: "))
        if start <= 0 or end <= 0:
            print("Inputs must be positive integers.")
            return
    except ValueError:
        print("Invalid input! Enter numbers only.")
        return

    primes = [n for n in range(start, end+1) if is_prime(n)]

    for i, p in enumerate(primes, 1):
        print(f"{p:5}", end="")
        if i % 10 == 0:
            print()
    print()

if __name__ == "__main__":
    main()
